const usuario = localStorage.getItem("usuario");
    const foto = localStorage.getItem("fotoPerfil");

    if (!usuario || !foto) {
      alert("Você precisa estar logado.");
      window.location.href = "login.html";
    } else {
      document.getElementById("nomeUsuario").innerText = `${usuario}`;
      document.getElementById("fotoPerfil").src = foto;
    }