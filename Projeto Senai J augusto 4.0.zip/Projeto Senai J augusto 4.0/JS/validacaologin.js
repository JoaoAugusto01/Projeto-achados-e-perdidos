function logar() {
    const usuario = document.getElementById("login-usuario").value;
    const senha = document.getElementById("login-senha").value;

    const usuarioSalvo = localStorage.getItem("usuario");
    const senhaSalva = localStorage.getItem("senha");

    if (usuario === usuarioSalvo && senha === senhaSalva) {
      window.location.href = "achadoseperdidos.html";
    } else {
      alert("Usuário ou senha incorretos.");
    }
  }