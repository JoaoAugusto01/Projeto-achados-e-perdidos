let itens = [];

    function mostrarLista() {
      document.getElementById("formAdicionar").style.display = "none";
      document.getElementById("listaItens").style.display = "block";

      const ul = document.getElementById("itensAchados");
      ul.innerHTML = "";

      if (itens.length === 0) {
        ul.innerHTML = "<li>Nenhum item cadastrado ainda.</li>";
      } else {
        itens.forEach((item, index) => {
          const li = document.createElement("li");

          const img = document.createElement("img");
          img.src = item.imagem;
          img.alt = `Imagem do item ${item.nome}`;
          img.onclick = () => abrirModalImagem(item.imagem);

          const span = document.createElement("span");
          span.innerText = `${index + 1}. ${item.nome}`;

          li.appendChild(img);
          li.appendChild(span);
          ul.appendChild(li);
        });
      }
    }

    function mostrarFormulario() {
      document.getElementById("listaItens").style.display = "none";
      document.getElementById("formAdicionar").style.display = "block";
    }

    function adicionarItem() {
      const inputNome = document.getElementById("novoItem");
      const inputImagem = document.getElementById("arquivoImagemItem");
      const nomeItem = inputNome.value.trim();

      if (nomeItem !== "" && inputImagem.files.length > 0) {
        const arquivo = inputImagem.files[0];
        const leitor = new FileReader();

        leitor.onload = function (e) {
          const imagemURL = e.target.result;
          itens.push({ nome: nomeItem, imagem: imagemURL });
          inputNome.value = "";
          inputImagem.value = "";
          mostrarLista();
          alert("Item adicionado com sucesso!");
        };

        leitor.readAsDataURL(arquivo);
      } else {
        alert("Digite o nome e selecione uma imagem.");
      }
    }

    // NOVAS FUNÇÕES para exibir imagem em modal
    function abrirModalImagem(imagemSrc) {
      const modal = document.getElementById("modalImagemItem");
      const img = document.getElementById("imagemModalExibida");
      img.src = imagemSrc;
      modal.style.display = "block";
    }

    function fecharModalImagem() {
      document.getElementById("modalImagemItem").style.display = "none";
    }