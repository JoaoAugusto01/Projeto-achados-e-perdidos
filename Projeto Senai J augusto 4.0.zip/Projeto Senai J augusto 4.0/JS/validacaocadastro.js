function cadastrar() {
    const usuario = document.getElementById("usuario").value;
    const senha = document.getElementById("senha").value;
    const foto = document.getElementById("file-upload").files[0];

    if (!usuario || !senha || !foto) {
      alert("Preencha todos os campos!");
      return;
    }

    const reader = new FileReader();
    reader.onload = function (e) {
      localStorage.setItem("usuario", usuario);
      localStorage.setItem("senha", senha);
      localStorage.setItem("fotoPerfil", e.target.result); // base64 da imagem

      alert("Cadastro concluído!");
      window.location.href = "login.html";
    };
    reader.readAsDataURL(foto);
  }