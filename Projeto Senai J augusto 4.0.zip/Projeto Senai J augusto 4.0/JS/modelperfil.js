document.getElementById("fotoPerfil").addEventListener("click", function() {
    const nome = document.getElementById("nomeUsuario").innerText;
    const fotoSrc = document.getElementById("fotoPerfil").src;

    document.getElementById("modalNomeUsuario").innerText = nome;
    document.getElementById("modalFotoPerfil").src = fotoSrc;

    document.getElementById("modalPerfil").style.display = "block";
});

function fecharPerfil() {
    document.getElementById("modalPerfil").style.display = "none";
}